package adt.avltree;

import adt.bst.BSTImpl;
import adt.bst.BSTNode;
import adt.bt.Util;

/**
 * 
 * Implementacao de uma arvore AVL
 * A CLASSE AVLTree herda de BSTImpl. VOCE PRECISA SOBRESCREVER A IMPLEMENTACAO
 * DE BSTIMPL RECEBIDA COM SUA IMPLEMENTACAO "OU ENTAO" IMPLEMENTAR OS SEGUITNES
 * METODOS QUE SERAO TESTADOS NA CLASSE AVLTREE:
 *  - insert
 *  - preOrder
 *  - postOrder
 *  - remove
 *  - height
 *  - size
 *
 * @author Claudio Campelo
 *
 * @param <T>
 */
public class AVLTreeImpl<T extends Comparable<T>> extends BSTImpl<T> implements
		AVLTree<T> {

	// TODO Do not forget: you must override the methods insert and remove
	// conveniently.

	// AUXILIARY
	protected int calculateBalance(BSTNode<T> node) {
		int balance = 0;
		if (node != null && !node.isEmpty()) {
			balance = recursiveHeight((BSTNode<T>)node.getLeft()) - recursiveHeight((BSTNode<T>)node.getRight());
		}
		return balance;
	}

	// AUXILIARY
	protected void rebalance(BSTNode<T> node) {
		if (node != null && !node.isEmpty()) {

			int balance = calculateBalance(node);
			if (Math.abs(balance) > 1) {
				
				if (balance > 1) {
					if (calculateBalance((BSTNode<T>)node.getLeft()) >= 0) {
						node = Util.rightRotation(node);
					} else {
						node.setLeft(Util.leftRotation((BSTNode<T>)node.getLeft()));
						node = Util.rightRotation(node);
					}
				
				} else if (balance < -1) {
					if (calculateBalance((BSTNode<T>)node.getRight()) <= 0) {
						node = Util.leftRotation(node);
					} else {
						node.setRight(Util.rightRotation((BSTNode<T>)node.getRight()));
						node = Util.leftRotation(node);
					}
				}
				if (node.getParent() == null) {
					this.root = node;
				}
			} 
		}
	}

	// AUXILIARY
	protected void rebalanceUp(BSTNode<T> node) {
		BSTNode<T> aux = node;
		while (aux != null) {
			int balance = calculateBalance(aux);
			if (Math.abs(balance) > 1) {
				rebalance(aux);
			}
			aux = (BSTNode<T>)aux.getParent(); 
		}
	}

	@Override
	public void insert(T element) {
		 if (element != null) {
			recursiveInsert(this.root, element);
		}
	}

	private void recursiveInsert(BSTNode<T> node, T element) {
		if (node.isEmpty()) {
			node.setData(element);
			node.setLeft(new BSTNode<T>());
			node.setRight(new BSTNode<T>());
			((BSTNode<T>) node.getLeft()).setParent(node);
			((BSTNode<T>) node.getRight()).setParent(node);
			rebalanceUp(node);
		} else {
			if (element.compareTo(node.getData()) > 0) {
				recursiveInsert((BSTNode<T>)node.getRight(), element);
			} else {
				recursiveInsert((BSTNode<T>)node.getLeft(), element);
			}
		}
	}

	@Override
	public void remove(T element) {
		if (element != null) {
			BSTNode<T> toRemove = search(element);
			recursiveRemove(toRemove);
		}
	}

	private void recursiveRemove(BSTNode<T> node) {
		if (node != null && !node.isEmpty()) {
			if (node.isLeaf()) {
				node.setData(null);
				node.setLeft(null);
				node.setRight(null);
				rebalanceUp((BSTNode<T>)node.getParent());
			} else if(node.getLeft().isEmpty() || node.getRight().isEmpty()) {
				BSTNode<T> filho;
				if (node.getLeft().isEmpty()) {
					filho = (BSTNode<T>)node.getRight();
				} else {
					filho = (BSTNode<T>)node.getLeft();
				}

				if (node.getParent() == null) {
					this.root = filho;
					this.root.setParent(null);
				} else {
					filho.setParent(node.getParent());
					if (filho.getData().compareTo(filho.getParent().getData()) < 0) {
						filho.getParent().setLeft(filho);
					} else {
						filho.getParent().setRight(filho);
					}
				}
				rebalanceUp((BSTNode<T>)node.getParent());
 			} else {
				BSTNode<T> next = sucessor(node.getData());
				node.setData(next.getData());
				recursiveRemove(next);
			}
		}
	}
}
