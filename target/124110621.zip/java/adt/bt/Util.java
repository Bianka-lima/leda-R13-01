package adt.bt;

import adt.bst.BSTNode;

public class Util {


	/**
	 * A rotacao a esquerda em node deve subir e retornar seu filho a direita
	 * @param node
	 * @return - noh que se tornou a nova raiz
	 */
	public static <T extends Comparable<T>> BSTNode<T> leftRotation(BSTNode<T> node) {
		BSTNode<T> no = node;
		if (node != null && !node.isEmpty() && node.right != null && !node.right.isEmpty()) {
			BSTNode<T> Root = node;
			BSTNode<T> pivot = (BSTNode<T>)node.right;
			BSTNode<T> RS = (BSTNode<T>)pivot.left;

			Root.right = pivot.left;
			if (RS != null) {
				RS.setParent(Root);
			}
			pivot.left = Root;

			pivot.setParent(node.parent);
			if (node.parent != null) {
				if (Root.getParent().getLeft().equals(Root)) {
					Root.getParent().setLeft(pivot);
				} else {
					Root.getParent().setRight(pivot);
				}
			}
			Root.setParent(pivot);
			no = pivot;
		}
		return no;
	}

	/**
	 * A rotacao a direita em node deve subir e retornar seu filho a esquerda
	 * @param node
	 * @return noh que se tornou a nova raiz
	 */
	public static <T extends Comparable<T>> BSTNode<T> rightRotation(BSTNode<T> node) {
		BSTNode<T> no = node;
		if (node != null && !node.isEmpty() && node.left != null && !node.left.isEmpty()) {
			BSTNode<T> Root = node;
			BSTNode<T> pivot = (BSTNode<T>)node.left;
			BSTNode<T> LS = (BSTNode<T>)pivot.right;

			Root.left = pivot.right;
			if (LS != null) {
				LS.setParent(Root);
			}
			pivot.right = Root;

			pivot.setParent(node.parent);
			if (node.parent != null) {
				if (Root.getParent().getLeft().equals(Root)) {
					Root.getParent().setLeft(pivot);
				} else {
					Root.getParent().setRight(pivot);
				}
			}
			Root.setParent(pivot);
			no = pivot;
		}
		return no;
	}

	public static <T extends Comparable<T>> T[] makeArrayOfComparable(int size) {
		@SuppressWarnings("unchecked")
		T[] array = (T[]) new Comparable[size];
		return array;
	}
}
